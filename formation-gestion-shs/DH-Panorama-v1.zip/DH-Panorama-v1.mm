<map version="freeplane 1.6.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="DH&#xa;HN" LOCALIZED_STYLE_REF="AutomaticLayout.level,1" FOLDED="false" ID="ID_124975604" CREATED="1490627620258" MODIFIED="1507753728833" COLOR="#ff6666" BACKGROUND_COLOR="#ccffcc" STYLE="oval">
<font SIZE="30" BOLD="true"/>
<hook NAME="MapStyle" zoom="1.5">
    <properties show_icon_for_attributes="true" fit_to_viewport="false;" show_note_icons="true" edgeColorConfiguration="#808080ff,#ff0000ff,#0000ffff,#00ff00ff,#ff00ffff,#00ffffff,#7c0000ff,#00007cff,#007c00ff,#7c007cff,#007c7cff,#7c7c00ff"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt">
<font SIZE="24"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="default" COLOR="#000000" STYLE="fork">
<font NAME="SansSerif" SIZE="10" BOLD="false" ITALIC="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details"/>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#000000" BACKGROUND_COLOR="#ffffff" TEXT_ALIGN="LEFT"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="styles.topic" COLOR="#18898b" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#cc3300" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#669900">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000" STYLE="oval" SHAPE_HORIZONTAL_MARGIN="10.0 pt" SHAPE_VERTICAL_MARGIN="10.0 pt">
<font SIZE="18"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#0033ff">
<font SIZE="16"/>
<edge COLOR="#ff0000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#00b439">
<font SIZE="14"/>
<edge COLOR="#0000ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#990000">
<font SIZE="12"/>
<edge COLOR="#00ff00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#111111">
<font SIZE="10"/>
<edge COLOR="#ff00ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5">
<edge COLOR="#00ffff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6">
<edge COLOR="#7c0000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7">
<edge COLOR="#00007c"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8">
<edge COLOR="#007c00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9">
<edge COLOR="#7c007c"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10">
<edge COLOR="#007c7c"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11">
<edge COLOR="#7c7c00"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="AutomaticEdgeColor" COUNTER="20" RULE="ON_BRANCH_CREATION"/>
<edge COLOR="#00cccc" WIDTH="2"/>
<richcontent TYPE="DETAILS">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &quot;Panorama des Humanit&#233;s num&#233;riques&quot;
    </p>
    <p>
      
    </p>
    <p>
      ANF Gestion de projets des sources num&#233;riques de la recherche en SHS
    </p>
    <p>
      (Laurence Rageot,&#160;&#160;Anne-Violaine Szabados, et alii.)
    </p>
    <p>
      v.1 : 09-10-2017
    </p>
    <p>
      CC-BY
    </p>
  </body>
</html>
</richcontent>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,1" FOLDED="true" POSITION="right" ID="ID_510971656" CREATED="1507536200574" MODIFIED="1507796725157" COLOR="#000000" BACKGROUND_COLOR="#ccffcc" STYLE="rectangle" HGAP_QUANTITY="-54.99999794363981 pt" VSHIFT_QUANTITY="-19.49999941885473 pt"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="6">Wikipedia :<b>&#160;&quot;Humanit&#233;s num&#233;riques&quot;</b></font>
    </p>
    <p>
      <font face="Times New Roman,serif"><a href="https://fr.wikipedia.org/wiki/Humanit%C3%A9s_num%C3%A9riques">https://fr.wikipedia.org/wiki/Humanit%C3%A9s_num%C3%A9riques</a></font>
    </p>
    <p>
      
    </p>
    <p>
      <font face="Calibri,sans-serif">- Les humanit&#233;s num&#233;riques (<i>Digital Humanities</i>) sont un domaine de recherche, d'enseignement et d&#8217;ing&#233;nierie <b>au croisement de l'informatique et des arts, lettres, sciences humaines et sciences sociales.</b><o p="#DEFAULT"></o></font>
    </p>
    <p>
      <font face="Calibri,sans-serif">- Elles <b>se caract&#233;risent par des m&#233;thodes et des pratiques li&#233;es &#224; l'utilisation des outils num&#233;riques, en ligne et hors ligne</b>, ainsi que par la volont&#233; de prendre en compte les nouveaux contenus num&#233;riques, au m&#234;me titre que des objets d'&#233;tude plus traditionnels.<o p="#DEFAULT"></o></font>
    </p>
    <p>
      <font face="Calibri,sans-serif">- Les humanit&#233;s num&#233;riques s'enracinent souvent d'une fa&#231;on explicite dans un mouvement <b>en faveur de la diffusion, du partage et de la valorisation du savoir</b>.<o p="#DEFAULT"></o></font>
    </p>
  </body>
</html>

</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#00cccc" WIDTH="2"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,1" ID="ID_1828668444" CREATED="1507407811248" MODIFIED="1507536944828" COLOR="#000000" BACKGROUND_COLOR="#ccffcc" STYLE="oval"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Manifeste</b>&#160;HN
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://tcp.hypotheses.org/category/manifeste">http://tcp.hypotheses.org/category/manifeste</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="30" BOLD="true"/>
<edge WIDTH="2"/>
<node TEXT="1. Le tournant num&#xe9;rique pris par la soci&#xe9;t&#xe9; modifie et interroge les conditions de production et de diffusion des savoirs.&#xa;2. Pour nous, les digital humanities concernent l&#x2019;ensemble des Sciences humaines et sociales, des Arts et des Lettres. Les digital humanities ne font pas table rase du pass&#xe9;. Elles s&#x2019;appuient, au contraire, sur l&#x2019;ensemble des paradigmes, savoir-faire et connaissances propres &#xe0; ces disciplines, tout en mobilisant les outils et les perspectives singuli&#xe8;res du champ du num&#xe9;rique.&#xa;&#x2026;&#xa;9. Nous lan&#xe7;ons un appel pour l&#x2019;acc&#xe8;s libre aux donn&#xe9;es et aux m&#xe9;tadonn&#xe9;es. Celles-ci doivent &#xea;tre document&#xe9;es et interop&#xe9;rables, autant techniquement que conceptuellement." LOCALIZED_STYLE_REF="AutomaticLayout.level,1" ID="ID_497840439" CREATED="1507536890038" MODIFIED="1507536908335" COLOR="#000000" BACKGROUND_COLOR="#ccffcc" STYLE="rectangle">
<font SIZE="12" BOLD="true"/>
<edge WIDTH="2"/>
</node>
</node>
</node>
<node TEXT="Institutions" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" FOLDED="true" POSITION="right" ID="ID_1902604588" CREATED="1493285123591" MODIFIED="1507536030185" COLOR="#990000">
<font SIZE="24" BOLD="true"/>
<edge COLOR="#990033"/>
<node TEXT="Infrastructures de Recherche" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_514271660" CREATED="1490627671179" MODIFIED="1507400896783">
<hook NAME="AlwaysUnfoldedNode"/>
<font SIZE="18" BOLD="true"/>
<node ID="ID_19590145" CREATED="1490627694449" MODIFIED="1507405203648" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      TGIR <b>Huma-Num</b>
    </p>
    <p>
      pour&#160;&#160;faciliter le tournant num&#233;rique de la recherche en lettres, sciences humaines et sociales ; humanit&#233;s num&#233;riques
    </p>
    <p>
      <a href="http://www.huma-num.fr/">http://www.huma-num.fr/</a>&#160;<o p="#DEFAULT"></o>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<node TEXT="Consortiums" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_1281667622" CREATED="1493284020316" MODIFIED="1507401049089">
<font SIZE="14" BOLD="true"/>
<node ID="ID_1434584885" CREATED="1493283919521" MODIFIED="1507403227000" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif"><b>Archives des ethnologues </b></font>
    </p>
    <p>
      <font face="SansSerif"><a href="http://ethnologues.huma-num.fr">http://ethnologues.huma-num.fr</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_889141356" CREATED="1493283758174" MODIFIED="1507403227031" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>CAHIER</b>
    </p>
    <p>
      &gt; corpus d&#8217;auteurs rel&#232;vant de la litt&#233;rature, de la philosophie ou d&#8217;une th&#233;matique li&#233;e &#224; une &#233;cole ou &#224; une pratique
    </p>
    <p>
      <font face="SansSerif"><a href="https://cahier.hypotheses.org/">https://cahier.hypotheses.org/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_940370779" CREATED="1493283969952" MODIFIED="1507403227049" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif"><b>Cartes et photographies pour les g&#233;ographes </b></font>
    </p>
    <p>
      <font face="SansSerif"><a href="http://humanum.hypotheses.org/191)">http://humanum.hypotheses.org/191</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_283322405" CREATED="1493283833073" MODIFIED="1507494446706" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="Times New Roman,serif"><b>CORLI</b>&#160;- CORpus Langues, Interactions</font>
    </p>
    <p>
      <font face="SansSerif"><a href="https://corli.huma-num.fr">https://corli.huhttp://tcp.hypotheses.org/category/manifestema-num.fr</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1991914802" CREATED="1507398667321" MODIFIED="1507403227070" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>IRCOM. Corpus oraux et</b>&#160;<b>multimodaux</b>
    </p>
    <p>
      <font face="SansSerif"><a href="http://ircom.huma-num.fr/site/">http://ircom.huma-num.fr/site/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_617411671" CREATED="1493283993667" MODIFIED="1507403227085" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif"><b>COSME</b> </font>
    </p>
    <p>
      <font face="SansSerif">&gt; </font>sources m&#233;di&#233;vales<font face="SansSerif">&#160;</font>
    </p>
    <p>
      <font face="SansSerif"><a href="http://cosme.hypotheses.org">http://cosme.hypotheses.org</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1771346357" CREATED="1493283716848" MODIFIED="1507403227101" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12.0pt" face="Times New Roman,serif"><b>MASA</b> </font>
    </p>
    <p>
      <strong><span style="font-size: 14px"><font size="14px">M&#233;moires des arch&#233;ologues et des sites arch&#233;ologiques</font></span></strong>
    </p>
    <p>
      <font size="12.0pt" face="Times New Roman,serif">(<a href="http://masa.hypotheses.org/)">http://masa.hypotheses.org/)</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_483334271" CREATED="1493283864891" MODIFIED="1507403227117" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif">MUSICA </font></span>
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif">(<a href="http://humanum.hypotheses.org/503)">http://humanum.hypotheses.org/503)</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_155197704" CREATED="1493283804811" MODIFIED="1507403227117" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>3D</b>
    </p>
    <p>
      <font face="Times New Roman,serif">(<a href="https://shs3d.hypotheses.org/)">https://shs3d.hypotheses.org/)</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1264910097" CREATED="1493283885404" MODIFIED="1507403227132" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif"><b>Archipolis </b></font>
    </p>
    <p>
      &gt; Archives des sciences sociales du politique
    </p>
    <p>
      (2012-2016)
    </p>
    <p>
      <font face="SansSerif"><a href="http://archipolis.hypotheses.org/-">http://archipolis.hypotheses.org/ </a></font>
    </p>
    <p>
      <font face="SansSerif"><a href="http://humanum.hypotheses.org/147">http://humanum.hypotheses.org/147</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1764756643" CREATED="1493283941428" MODIFIED="1507403226985" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif"><b>Archives des mondes contemporains </b></font>
    </p>
    <p>
      (2012-2016)
    </p>
    <p>
      <font face="SansSerif"><a href="http://arcmc.hypotheses.org">http://arcmc.hypotheses.org </a>- <a href="http://humanum.hypotheses.org/231)">http://humanum.hypotheses.org/231</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
</node>
<node ID="ID_734558197" CREATED="1507404943153" MODIFIED="1507494744108" LINK="#ID_1085969723" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font color="#333333">DARIAH-</font>FR</b>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_364360836" CREATED="1507405018585" MODIFIED="1507494560082" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Fourniture de services et d'outils (achat de licences collectives pour tous les membres de l'ESR)
    </p>
    <p>
      &#160;<span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://www.huma-num.fr/services-et-outils/traiter">http://www.huma-num.fr/services-et-outils/traiter</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<node ID="ID_332147154" CREATED="1507494055105" MODIFIED="1507494809584" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Moteur de recherche <b>ISIDORE</b>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00ff"/>
</node>
<node ID="ID_150200806" CREATED="1507494018049" MODIFIED="1507544440557" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Nakala</b>
    </p>
    <p>
      triplestore (entrepot de donn&#233;es RDF)
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Calibri,sans-serif"><font size="12.0pt" face="Calibri,sans-serif"><a href="https://www.nakala.fr/">https://www.nakala.fr/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00ff"/>
</node>
<node ID="ID_1273288454" CREATED="1507494045273" MODIFIED="1507544474097" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      pack <b>Nakalona</b>
    </p>
    <p>
      Nakala + interface de saisie/diffusion <i>Omeka </i>
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Calibri,sans-serif"><font size="12.0pt" face="Calibri,sans-serif"><a href="https://www.nakalona.fr/">https://www.nakalona.fr/</a></font></span>&#160;
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00ff"/>
</node>
</node>
<node TEXT="Guides de bonnes pratiques" ID="ID_276074576" CREATED="1507405087124" MODIFIED="1507405105238" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble">
<font SIZE="13" BOLD="false"/>
</node>
</node>
<node ID="ID_245179181" CREATED="1490627732246" MODIFIED="1507405210051" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      TGIR <b>Progedo</b>&#160;:
    </p>
    <p>
      impulser et structurer une politique publique des donn&#233;es pour la recherche en sciences sociales (particuli&#232;rement la recherche en droit, &#233;conomie, g&#233;ographie, gestion, histoire, sciences politiques et sociologie)
    </p>
    <p>
      <font face="Times New Roman,serif"><a href="http://www.progedo.fr/)">http://www.progedo.fr/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_1713592231" CREATED="1493284175564" MODIFIED="1507493737878"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4" face="SansSerif">Plate-forme Universitaire de Donn&#233;es </font>
    </p>
  </body>
</html>
</richcontent>
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#990000" WIDTH="1" TRANSPARENCY="160" DASH="3 3" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_17696629" STARTINCLINATION="111;2;" ENDINCLINATION="-132;-39;" STARTARROW="NONE" ENDARROW="NONE"/>
<font SIZE="14" BOLD="true"/>
<node ID="ID_592987475" CREATED="1493284230883" MODIFIED="1507403207424" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>MISHA</b>&#160;: Plate-forme Universitaire de Donn&#233;es (Alsace)
    </p>
    <p>
      <a href="http://www.misha.fr/page_pud_s.htm">http://www.misha.fr/page_pud_s.htm</a><o p="#DEFAULT"></o>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_993248967" CREATED="1493284266205" MODIFIED="1507403207477" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="7.0pt" face="Times New Roman">&#160;</font>Plate-forme Universitaire de Donn&#233;es de Caen (<b>PUDC</b>)&#160;
    </p>
    <p>
      <a href="http://recherche.unicaen.fr/laboratoires/sciences-humaines-et-sociales/plate-forme-universitaire-de-donnees-de-caen-pudc--281479.kjsp?RH=1275393556320">http://recherche.unicaen.fr/laboratoires/sciences-humaines-et-sociales/plate-forme-universitaire-de-donnees-de-caen-pudc--281479.kjsp?RH=1275393556320</a><o p="#DEFAULT"></o>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_840548815" CREATED="1493284452147" MODIFIED="1507494618078" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      MSH Clermont-Ferrand : Informatique - bases de donn&#233;es
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://msh-clermont.fr/panel-informatique-et-base-de-donn%C3%A9es">http://msh-clermont.fr/panel-informatique-et-base-de-donn%C3%A9es</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1057713539" CREATED="1493284360731" MODIFIED="1507494681071" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>MSH Dijon</b>&#160;: Plate-forme Universitaire de Donn&#233;es (PUD)&#160;
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://msh-dijon.u-bourgogne.fr/plateforme-universitaire-de-donnees.html">http://msh-dijon.u-bourgogne.fr/plateforme-universitaire-de-donnees.html</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_536133181" CREATED="1493284326817" MODIFIED="1507403207524" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="7.0pt" face="Times New Roman">&#160;</font>MSH Ange-Gu&#233;pin</b>&#160;: Plate-forme Progedo-Nantes
    </p>
    <p>
      &#160;<a href="http://www.msh.univ-nantes.fr/79948827/0/fiche___pagelibre/&amp;RH=ACCUEIL&amp;RF=1443780509285">http://www.msh.univ-nantes.fr/79948827/0/fiche___pagelibre/&amp;RH=ACCUEIL&amp;RF=1443780509285</a><o p="#DEFAULT"></o>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1472619324" CREATED="1493284293150" MODIFIED="1507405135902" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <span style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 7.0pt; line-height: normal; font-family: Times New Roman"><font size="7.0pt" face="Times New Roman">&#160;</font></span><span lang="EN-US">l'ISH : PANELS </span>
    </p>
    <p>
      <a href="https://www.ish-lyon.cnrs.fr/panels"><span lang="EN-US">https://www.ish-lyon.cnrs.fr/panels</span></a><span lang="EN-US"><o p="#DEFAULT"></o></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_735851022" CREATED="1493284200825" MODIFIED="1507403281243" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <span style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 7.0pt; line-height: normal; font-family: Times New Roman"><font size="7.0pt" face="Times New Roman">&#160;</font></span>Plate-forme Universitaire de Donn&#233;es de Lille (PUDL)&#160;
    </p>
    <p>
      <a href="https://pudl.meshs.fr/">https://pudl.meshs.fr/</a><o p="#DEFAULT"></o>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1200514336" CREATED="1493284406124" MODIFIED="1507403207562" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>MSH Saclay</b>&#160;: Plate-forme Universitaire de Donn&#233;es
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_180943283" CREATED="1493284382021" MODIFIED="1507494868538" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>MSHS-T (Toulouse)</b>&#160;: Plate-forme Universitaire de Donn&#233;es
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://mshs.univ-toulouse.fr/spip.php?article27&#x2329;=fr">http://mshs.univ-toulouse.fr/spip.php?article27&amp;lang=fr</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_582620005" CREATED="1493284430775" MODIFIED="1507494902492" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>MMSH</b>&#160;: Observatoire D&#233;mographique de la M&#233;diterrann&#233;e (DemoMEd) / MAJIC
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://demomed.org/index.php/fr/">http://demomed.org/index.php/fr/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_1674947697" CREATED="1493283245946" MODIFIED="1507405138622" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>R&#233;seau national des MSH</b>&#160;(<b>RnMSH</b>)
    </p>
    <p>
      Maisons des Sciences de l'Homme
    </p>
    <p>
      <a href="http://www.msh-reseau.fr/">http://www.msh-reseau.fr/</a><o p="#DEFAULT"></o>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<node TEXT="Plates-formes" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_17696629" CREATED="1507401373135" MODIFIED="1507405138622"><richcontent TYPE="DETAILS">

<html>
  <head>
    
  </head>
  <body>
    <p>
      http://www.msh-reseau.fr/plate-formes
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
<node ID="ID_1516522165" CREATED="1507401708839" MODIFIED="1507403194636" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="http://www.msh-reseau.fr/plate-formes?8"><strong>plates-formes Audio-Visio</strong></a>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1067908385" CREATED="1507401809008" MODIFIED="1507403194652" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="http://www.msh-reseau.fr/plate-formes?9"><strong>plates-formes Cogito</strong></a>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1782789543" CREATED="1507401944840" MODIFIED="1507495006180" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="http://www.msh-reseau.fr/plate-formes?10"><strong><font size="3">plates-formes Data</font></strong></a>
    </p>
    <p>
      <font size="3">(qualitatif &amp; quantitatif)</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1629698964" CREATED="1507401505669" MODIFIED="1507403194683" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="http://www.msh-reseau.fr/plate-formes?7"><strong>plates-formes Scripto</strong></a>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1682919585" CREATED="1507401394951" MODIFIED="1507403194699" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="http://www.msh-reseau.fr/plate-formes?6"><strong>plates-formes Spatio</strong></a>
    </p>
    <p>
      (spatial, image, 3D)
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1512129104" CREATED="1507402202682" MODIFIED="1507403194598" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="http://www.msh-reseau.fr/plate-formes?11"><strong>Plate-forme web d&#8217;internationalisation Fundit</strong></a>
    </p>
    <p>
      (appels d'offre mobilit&#233; &amp; financement)
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
</node>
</node>
<node ID="ID_1407878373" CREATED="1493283297998" MODIFIED="1507495070842" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font color="#333333" face="Times New Roman,serif"><b>E-RIHS-</b></font><b><font face="Times New Roman,serif">FR </font></b>
    </p>
    <p>
      <font color="#333333" face="SansSerif">European Research Infrastructure for Heritage Science</font><font color="#990000" face="SansSerif">&#160; </font>
    </p>
    <p>
      <font face="SansSerif" color="#000000">d&#233;di&#233;e &#224; l&#8217;&#233;tude des mat&#233;riaux du&#160;patrimoine culturel et naturel</font>
    </p>
    <p>
      <font face="Times New Roman,serif"><a href="http://www.erihs.fr/">http://www.erihs.fr/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1581028126" CREATED="1493283335317" MODIFIED="1507495105009" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="Times New Roman,serif"><b>NUMEDIF</b>&#160;</font>
    </p>
    <p>
      <font face="Times New Roman,serif">NUM&#233;rique pour l'&#201;DItion et la DIFFusion de la production scientifique : </font>
    </p>
    <p>
      <font face="Times New Roman,serif">&#160;<a href="http://www.enseignementsup-recherche.gouv.fr/cid99664/numedif-numerique-pour-l-edition-et-la-diffusion-de-la-production-scientifique-numedif.html">http://www.enseignementsup-recherche.gouv.fr/cid99664/numedif-numerique-pour-l-edition-et-la-diffusion-de-la-production-scientifique-numedif.html</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_283801790" CREATED="1493283381002" MODIFIED="1507495226855" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="Times New Roman,serif"><b>COLLEX-PERSEE </b></font>
    </p>
    <p>
      <font face="Times New Roman,serif">Collections d'excellence pour la Recherche &#8211;&#160;Pers&#233;e </font>
    </p>
    <p>
      Dispositif national de coop&#233;ration documentaire pour optimiser l&#8217;acc&#232;s aux gisements documentaires par les chercheurs
    </p>
    <p>
      <font face="Times New Roman,serif"><a href="http://www.collex.eu/">http://www.collex.eu/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1769277185" CREATED="1493283584870" MODIFIED="1507495718765" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12.0pt" face="Times New Roman,serif"><b>HAL</b>&#160;</font>
    </p>
    <p>
      <font face="Times New Roman,serif"><a href="https://halshs.archives-ouvertes.fr/">https://halshs.archives-ouvertes.fr/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<node ID="ID_1758766567" CREATED="1507417522708" MODIFIED="1507495382535" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      HAL-SHS
    </p>
    <p>
      d&#233;p&#244;t et &#224; la diffusion d'articles scientifiques de niveau recherche
    </p>
    <p>
      <span><b><font size="12.0pt" face="Times New Roman,serif"><a href="https://halshs.archives-ouvertes.fr/">https://halshs.archives-ouvertes.fr/</a></font></b></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
<node ID="ID_1624509452" CREATED="1507417535131" MODIFIED="1507751283277" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>MediHal</b>
    </p>
    <p>
      archive ouverte permettant de d&#233;poser des donn&#233;es visuelles et sonores (images fixes, vid&#233;os et sons)
    </p>
    <p class="MsoNormal">
      <span class="MsoHyperlink"><a href="https://medihal.archives-ouvertes.fr/">https://medihal.archives-ouvertes.fr/</a><o p="#DEFAULT"></o></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
<node ID="ID_1552330139" CREATED="1507494101987" MODIFIED="1507495591195" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>&#233;pisciences.org</b>
    </p>
    <p>
      plateforme d'&#233;pi-revues (revues &#233;lectroniques en libre acc&#232;s, aliment&#233;es par les articles d&#233;pos&#233;s dans les archives ouvertes telles que HAL ou arXiv, et non publi&#233;s par ailleurs)
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="https://www.episciences.org/">https://www.episciences.org/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
<node ID="ID_772658935" CREATED="1507495619333" MODIFIED="1507495727255" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Sciencesconf.org</b>&#160;
    </p>
    <p>
      plateforme Web s'adressant aux organisateurs de colloques, workshops ou r&#233;unions scientifiques
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="https://www.sciencesconf.org/">https://www.sciencesconf.org/</a>&#160;</font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
</node>
<node ID="ID_556794194" CREATED="1493283616919" MODIFIED="1507495958206" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>OpenEdition</b>&#160;(<span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="https://www.openedition.org/">https://www.openedition.org/</a></font></span>)
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<node ID="ID_1625372259" CREATED="1493284923680" MODIFIED="1507496330294" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="3">calenda</font></b><font size="3">&#160;(</font><span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://calenda.org/">http://calenda.org/</a></font></span><font size="12.0pt" face="Times New Roman,serif"><span style="font-size: 12.0pt; font-family: Times New Roman,serif">&#160;</span></font><font size="3">) : annonce d'&#233;v&#233;nements</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
<node ID="ID_1494407919" CREATED="1493284937338" MODIFIED="1507496138315" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="3">Hypotheses</font></b><font size="3">&#160;(</font><span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="https://fr.hypotheses.org/">https://fr.hypotheses.org/</a></font></span><font size="3">) : plateforme de carnets de recherche / blog</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
<node ID="ID_358781482" CREATED="1493284949532" MODIFIED="1507496190609" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="3"><b>revues.org</b>&#160;(</font><span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://www.revues.org/">http://www.revues.org/</a></font></span><font size="3">),</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
<node ID="ID_1559815975" CREATED="1493284966170" MODIFIED="1507496259604" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="3"><b>openedition books </b>(</font><span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="https://books.openedition.org/">https://books.openedition.org/</a>&#160;</font></span><font size="3">)</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
</node>
</node>
<node TEXT="Autres institutions Fran&#xe7;aises" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_1242471620" CREATED="1493285147766" MODIFIED="1493288121395">
<font SIZE="18" BOLD="true"/>
<node ID="ID_1342493927" CREATED="1493285337352" MODIFIED="1507404430907" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="Times New Roman,serif"><b>Minist&#232;re de la Culture et de la Communication</b></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<node ID="ID_490536412" CREATED="1493285386267" MODIFIED="1507496341371" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif">Mission Etalab </font></span>
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="https://www.etalab.gouv.fr/"><b>https://www.etalab.gouv.fr/</b></a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="false"/>
<edge COLOR="#009900"/>
</node>
<node FOLDED="true" ID="ID_189351830" CREATED="1493285417317" MODIFIED="1507496072709" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="Times New Roman,serif">programme <b>HADOC</b>&#160;-&#160;&#160;Harmonisation des donn&#233;es culturelles </font>
    </p>
    <p>
      <font face="Times New Roman,serif"><a href="http://www.culturecommunication.gouv.fr/Divers/Harmonisation-des-donnees-culturelles">http://www.culturecommunication.gouv.fr/Divers/Harmonisation-des-donnees-culturelles</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<edge COLOR="#009900"/>
<node TEXT="normes &amp; standards" ID="ID_540136632" CREATED="1507403648313" MODIFIED="1507404305536" COLOR="#0066cc" BACKGROUND_COLOR="#ccffcc" STYLE="bubble">
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
<node TEXT="outils, logiciels" ID="ID_1932746837" CREATED="1507403708197" MODIFIED="1507404402809" COLOR="#0066cc" BACKGROUND_COLOR="#fbdbdb" STYLE="bubble">
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
<node TEXT="vocabulaires et r&#xe9;f&#xe9;rentiels" ID="ID_24112248" CREATED="1507403660761" MODIFIED="1507404362828" COLOR="#0066cc" BACKGROUND_COLOR="#ffffcc" STYLE="bubble">
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
</node>
</node>
<node ID="ID_1936037372" CREATED="1493285255582" MODIFIED="1507404603786" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Archives nationales</b>
    </p>
    <p>
      http://www.archivesnationales.culture.gouv.fr/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_797080274" CREATED="1493285285257" MODIFIED="1507404617754" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Archives de France</b>
    </p>
    <p>
      https://francearchives.fr/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1668061925" CREATED="1493285218765" MODIFIED="1507408467259" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12.0pt" face="Times New Roman,serif"><b>BNF</b>&#160;: </font>
    </p>
    <p>
      <font size="12.0pt" face="Times New Roman,serif"><a href="http://www.bnf.fr/">http://www.bnf.fr/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="18" BOLD="true"/>
<node TEXT="Gallica" ID="ID_1434391063" CREATED="1493285248307" MODIFIED="1507404573652" COLOR="#0066cc" BACKGROUND_COLOR="#d1e8ff" STYLE="bubble">
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
<node TEXT="data.bnf" ID="ID_34647885" CREATED="1507404458427" MODIFIED="1507404555759" COLOR="#0066cc" BACKGROUND_COLOR="#ffdaff" STYLE="bubble">
<font SIZE="13" BOLD="false"/>
</node>
</node>
<node ID="ID_1110037650" CREATED="1493285188531" MODIFIED="1507404441647" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12.0pt" face="Times New Roman,serif"><b>CINES</b>&#160;</font>
    </p>
    <p>
      <font size="12.0pt" face="Times New Roman,serif"><em>Centre Informatique National de l'Enseignement Sup&#233;rieur</em>&#160;</font>
    </p>
    <p>
      <font size="12.0pt" face="Times New Roman,serif"><a href="https://www.cines.fr/">https://www.cines.fr/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_789252114" CREATED="1493285313623" MODIFIED="1507493534072" COLOR="#0066cc" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif" size="3"><b>R&#233;seau Quetelet</b>&#160; </font>
    </p>
    <p>
      <font face="SansSerif" size="3">Grandes enqu&#234;tes, recensements et autres bases de donn&#233;es issues de la statistique publique fran&#231;aise,&#160;&#160;grandes enqu&#234;tes fran&#231;aises provenant de la recherche,&#160;&#160;acc&#232;s privil&#233;gi&#233; &#224; des enqu&#234;tes internationales </font>
    </p>
    <p>
      <font face="SansSerif" size="3"><a href="http://www.reseau-quetelet.cnrs.fr/spip/">http://www.reseau-quetelet.cnrs.fr/spip/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
</node>
<node TEXT="Infrastrutures ou programmes Europ&#xe9;ens" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_1916533481" CREATED="1493285578455" MODIFIED="1493288143435">
<font SIZE="18" BOLD="true"/>
<node ID="ID_1085969723" CREATED="1493285636925" MODIFIED="1507496395894" COLOR="#000000" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>DARIAH</b>&#160;Digital Research Infrastructure for the Arts and Humanities
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://dariah.eu/">http://dariah.eu/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#990000" WIDTH="1" TRANSPARENCY="200" DASH="3 3" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_734558197" STARTINCLINATION="1076;-91;" ENDINCLINATION="1504;-298;" STARTARROW="NONE" ENDARROW="NONE"/>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1017670193" CREATED="1493285649823" MODIFIED="1507493505675" COLOR="#000000" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12.0pt" face="SansSerif"><b>CLARIN</b>&#160;</font>
    </p>
    <p>
      <font size="12.0pt" face="SansSerif">European Research Infrastructure for Language Resources and Technology </font>
    </p>
    <p>
      <font face="SansSerif"><a href="https://www.clarin.eu/">https://www.clarin.eu/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_58854753" CREATED="1493285673443" MODIFIED="1507493505694" COLOR="#000000" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif"><b>ARIADNE</b>&#160; </font>
    </p>
    <p>
      <font face="SansSerif">(arch&#233;ologie)</font>
    </p>
    <p>
      <font face="SansSerif"><a href="http://www.ariadne-infrastructure.eu/)">http://www.ariadne-infrastructure.eu/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
<node TEXT="outils, logiciels" ID="ID_833172093" CREATED="1507403708197" MODIFIED="1507406207365" COLOR="#666666" BACKGROUND_COLOR="#fbdbdb" STYLE="bubble">
<font SIZE="13" BOLD="false"/>
<edge COLOR="#ff00cc"/>
</node>
</node>
<node ID="ID_270349423" CREATED="1493285705369" MODIFIED="1507493505697" COLOR="#000000" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12.0pt" face="SansSerif"><b>PARTHENOS</b>&#160;</font>
    </p>
    <p>
      <font size="12.0pt" face="SansSerif">Pooling Activities, Resources and Tools for Heritage E-research Networking, Optimization and Synergies </font>
    </p>
    <p>
      <font face="SansSerif"><a href="http://www.parthenos-project.eu/">http://www.parthenos-project.eu/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_20764843" CREATED="1493285735648" MODIFIED="1507493505697" COLOR="#000000" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif"><b>Athena+ </b></font>
    </p>
    <p>
      <font face="SansSerif"><a href="http://www.athenaplus.eu/">http://www.athenaplus.eu/</a>&#160; </font>
    </p>
    <p>
      <font face="SansSerif">(documentation et fascicules)</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_1759495061" CREATED="1493285756230" MODIFIED="1507493505697" COLOR="#000000" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif"><b>3D icons</b>&#160;</font>
    </p>
    <p>
      <font face="SansSerif"><a href="http://www.3dicons.ie/">http://www.3dicons.ie/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
</node>
<node TEXT="autres Infrastructures&#xa;ou programmes" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_743513087" CREATED="1507544099944" MODIFIED="1507544201848">
<font SIZE="18" BOLD="true"/>
<node ID="ID_171278023" CREATED="1507544133495" MODIFIED="1507544251975" COLOR="#000000" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <span lang="EN-US" style="font-family: Calibri,sans-serif"><font face="Calibri,sans-serif" size="3"><b>Library of Congress (USA)<o p="#DEFAULT" size="3"></o></b></font></span>
    </p>
    <span lang="EN-US"><font size="3" face="Calibri,sans-serif"><a href="https://www.loc.gov/">https://www.loc.gov/</a></font></span>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_279727481" CREATED="1507544230638" MODIFIED="1507544254327" COLOR="#000000" BACKGROUND_COLOR="#ffffff" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <span lang="EN-US" style="font-family: Calibri,sans-serif"><font face="Calibri,sans-serif" size="3"><b>Digital Public Library of America <o p="#DEFAULT" size="3"></o></b></font></span>
    </p>
    <span lang="EN-US"><font size="3" face="Calibri,sans-serif"><a href="https://dp.la/">https://dp.la/</a></font></span>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" FOLDED="true" POSITION="right" ID="ID_1052633116" CREATED="1493285873215" MODIFIED="1507406064536" COLOR="#009999" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2>
      <span>R&#233;seaux <o p="#DEFAULT"></o></span>
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="24" BOLD="true"/>
<edge WIDTH="2"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_279279334" CREATED="1493285456587" MODIFIED="1507478779725" COLOR="#009999"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2>
      <span lang="EN-US">Associations et f&#233;d&#233;rations<o p="#DEFAULT"></o></span>
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="18" BOLD="true"/>
<node ID="ID_948073531" CREATED="1493285473822" MODIFIED="1507406419812" COLOR="#333333" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>W3C-</b>World Wide Web Consortium
    </p>
    <p>
      https://www.w3.org/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
<edge COLOR="#00cccc"/>
</node>
<node ID="ID_1325401450" CREATED="1493285499072" MODIFIED="1507406513993" COLOR="#333333" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>ADHO</b>&#160;- Alliance of Digital Humanities Organizations
    </p>
    <p>
      http://adho.org/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
<edge COLOR="#00cccc"/>
</node>
<node ID="ID_496065204" CREATED="1493285554489" MODIFIED="1507407021874" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font color="#333333">Humanistica</font> </b>
    </p>
    <p>
      (francophone)
    </p>
    <p>
      http://www.humanisti.ca/
    </p>
  </body>
</html>
</richcontent>
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#00cccc" WIDTH="2" TRANSPARENCY="200" DASH="3 3" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1325401450" STARTINCLINATION="199;0;" ENDINCLINATION="199;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font SIZE="13"/>
<edge COLOR="#00cccc"/>
</node>
<node ID="ID_1401066372" CREATED="1493285531680" MODIFIED="1507751417560" COLOR="#333333" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font face="SansSerif" size="3">IFLA</font></b><font face="SansSerif" size="3">- International Federation of Library Associations and Institutions </font>
    </p>
    <p>
      <font size="3" face="SansSerif"><a href="https://www.ifla.org/">https://www.ifla.org/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
<edge COLOR="#00cccc"/>
</node>
<node ID="ID_729001917" CREATED="1493285795533" MODIFIED="1507406458112" COLOR="#333333" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12.0pt" face="Times New Roman,serif">&#160;<b>TEI</b>&#160;(consortium international) Text Encoding Initiative </font>
    </p>
    <p>
      <font size="12.0pt" face="Times New Roman,serif">&#160;<a href="http://www.tei-c.org/index.xml">http://www.tei-c.org/index.xml</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
<edge COLOR="#00cccc"/>
</node>
<node ID="ID_999902819" CREATED="1493285822470" MODIFIED="1507409060821" COLOR="#333333" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12.0pt" face="Times New Roman,serif">&#160;<b>CIDOC</b>&#160;(ICOM) </font>
    </p>
    <p>
      <font size="12.0pt" face="Times New Roman,serif">(mus&#233;es)</font>
    </p>
    <p>
      <font size="12.0pt" face="Times New Roman,serif">&#160;<a href="http://network.icom.museum/cidoc/">http://network.icom.museum/cidoc/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
</node>
<node ID="ID_1472736086" CREATED="1507409028396" MODIFIED="1507409216490" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Framasoft</b>
    </p>
    <p>
      (r&#233;seau d&#233;di&#233; &#224; la promotion du &#171;&#160;libre&#160;&#187; en g&#233;n&#233;ral et du logiciel libre&#160;en particulier)
    </p>
    <p>
      https://framasoft.org/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
<edge COLOR="#00cccc"/>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_122795994" CREATED="1493288162548" MODIFIED="1507405984733" COLOR="#009999"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="5">Listes de diffusion</font></b>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="18"/>
<node ID="ID_433325460" CREATED="1493285893566" MODIFIED="1507406803399" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4" face="Times New Roman,serif">liste <b>DH</b></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
<edge COLOR="#00cccc"/>
</node>
<node ID="ID_188021253" CREATED="1493285920166" MODIFIED="1507406818879" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="Times New Roman,serif" size="4">liste <b>accesouvert</b></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
<edge COLOR="#00cccc"/>
</node>
<node ID="ID_1365762113" CREATED="1493285929265" MODIFIED="1507406836309" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4" face="Times New Roman,serif">liste <b>ontologie-patrimoine</b></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
<edge COLOR="#00cccc"/>
</node>
<node ID="ID_327628399" CREATED="1493285964085" MODIFIED="1507407124209" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4" face="Times New Roman,serif"><b>ISORE</b>&#160;(documentalistes SHS)</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
</node>
<node ID="ID_1881232959" CREATED="1493285951530" MODIFIED="1507407117779" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4" face="Times New Roman,serif"><b>MATE-SHS</b></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
</node>
<node ID="ID_821140574" CREATED="1493285977521" MODIFIED="1507407114197" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4" face="Times New Roman,serif"><b>MEDICI</b>&#160;(Publication)</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
</node>
<node ID="ID_291928941" CREATED="1507407033889" MODIFIED="1507407190596" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="3"><b>RBDD </b></font>
    </p>
    <p>
      <font size="3">R&#233;seau Bases De Donn&#233;es</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13"/>
</node>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" POSITION="left" ID="ID_965411782" CREATED="1493286021007" MODIFIED="1507797249394" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif" size="4">Standards, normes, </font>
    </p>
    <p>
      <font face="SansSerif" size="4">mod&#232;les conceptuels, </font>
    </p>
    <p>
      <font face="SansSerif" size="4"><a href="https://fr.wikipedia.org/wiki/Ontologie_(informatique)">ontologies informatiques</a>&#160;</font>
    </p>
  </body>
</html>

</richcontent>
<font SIZE="24" BOLD="true"/>
<edge COLOR="#00cc66"/>
<node ID="ID_1961198678" CREATED="1493286045726" MODIFIED="1507750635281" COLOR="#009933" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12.0pt" face="SansSerif">Documentation et sour&#231;age</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<node FOLDED="true" ID="ID_411325274" CREATED="1493286063116" MODIFIED="1507750585728" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif" size="3"><b>DC - Dublin Core &#160; </b></font>
    </p>
    <p>
      <font face="SansSerif" size="3"><b>DCMI - Dublin Core Metadata Initiative</b>&#160;.&#160;&#160;DCterms </font>
    </p>
    <p>
      <font face="SansSerif" size="3">M&#233;tadonn&#233;es pour documenter un fichier </font>
    </p>
    <p>
      <font face="SansSerif" size="3"><a href="http://dublincore.org/">http://dublincore.org/</a>&#160;</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="false"/>
<node ID="ID_1579939717" CREATED="1507409496144" MODIFIED="1507749937735" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>DC elements</b>
    </p>
    <p>
      (Dublin Core simple : 15 &#233;l&#233;ments)
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="false"/>
</node>
<node TEXT="dcterms" ID="ID_1078429697" CREATED="1507409511493" MODIFIED="1507410389411" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node ID="ID_1777686317" CREATED="1507453976511" MODIFIED="1507750519718" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font face="SansSerif" size="3">METS - Metadata Encoding and Transmission Standard</font></b>
    </p>
    <p>
      <font face="SansSerif" size="3">Sch&#233;ma xml pour documenter int&#233;gralement (description, adminisitratif, structure)&#160;&#160;d'objets num&#233;riques&#160;&#160;textuels ou graphiques. Pour &#233;changes ; conforme OAIS. </font>
    </p>
    <p>
      <span style="font-size: 11.0pt; line-height: 107%; font-family: Calibri,sans-serif"><font size="11.0pt" face="Calibri,sans-serif"><a href="http://www.loc.gov/standards/mets/">http://www.loc.gov/standards/mets/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="false"/>
</node>
<node ID="ID_134731483" CREATED="1493286086606" MODIFIED="1507750371276" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif" size="3"><b>PROV - PROV Data Model</b>&#160;: for provenance interchange on the web. </font>
    </p>
    <p>
      <font size="3">Pour renseigner la source des donn&#233;es </font>
    </p>
    <p>
      <font face="SansSerif" size="3"><a href="https://www.w3.org/TR/prov-primer/">https://www.w3.org/TR/prov-primer/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="false"/>
</node>
</node>
<node ID="ID_1325204109" CREATED="1493286102325" MODIFIED="1507750545826" COLOR="#009933" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif" size="3">Archives et personnes </font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<node ID="ID_1984344107" CREATED="1507410201323" MODIFIED="1507750628417" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif" size="3"><b>EAD&#160;- Encoded Archival Description </b></font>
    </p>
    <p>
      <font face="SansSerif" size="3">Schema XML pour structurer des descriptions de manuscrits ou de documents d'archives </font>
    </p>
    <p>
      <font face="SansSerif,serif" size="3"><a href="http://www.bnf.fr/fr/professionnels/formats_catalogage/a.f_ead.html">http://www.bnf.fr/fr/professionnels/formats_catalogage/a.f_ead.html</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="false"/>
</node>
<node ID="ID_957410973" CREATED="1507409999577" MODIFIED="1507750842068" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="3" face="SansSerif"><b>EAC-CPF</b>&#160;: Encoded Archival Context - Corporate bodies, Persons, Families </font>
    </p>
    <p>
      <font face="SansSerif"><a href="http://eac.staatsbibliothek-berlin.de/">http://eac.staatsbibliothek-berlin.de/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="false"/>
</node>
<node ID="ID_441339540" CREATED="1507410571547" MODIFIED="1507750719534" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="3"><b>FOAF</b>&#160;<b>- </b>Friend of a Friend </font>
    </p>
    <p>
      <font size="3">Ontologie RDF pour d&#233;crire les personnes et leurs relations </font>
    </p>
    <p>
      <span style="font-size: 11.0pt; line-height: 107%; font-family: Calibri,sans-serif"><font size="11.0pt" face="Calibri,sans-serif"><a href="http://www.foaf-project.org/">http://www.foaf-project.org/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="false"/>
</node>
</node>
<node ID="ID_1480905444" CREATED="1493286244374" MODIFIED="1507750732533" COLOR="#009933" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3>
      <font size="3">Archivage</font><o p="#DEFAULT"></o>
    </h3>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
<node ID="ID_724037661" CREATED="1507408544069" MODIFIED="1507751623899" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif" size="3"><b>OAI-PMH</b>&#160;- Open Archives Initiative Protocol for Metadata Harvesting </font>
    </p>
    <p>
      <font face="SansSerif" size="3">Protocole informatique de moissonnage et cr&#233;ation d'entrep&#244;ts de (m&#233;ta)donn&#233;es. </font>
    </p>
    <p>
      <font face="SansSerif" size="3"><a href="https://www.openarchives.org/pmh/">https://www.openarchives.org/pmh/</a>&#160;</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="false"/>
</node>
</node>
<node ID="ID_432385667" CREATED="1493286119823" MODIFIED="1507750966853" COLOR="#009933" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3>
      <font size="3">Biblioth&#232;ques<o p="#DEFAULT" size="3"></o></font>
    </h3>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="false"/>
<node ID="ID_411666672" CREATED="1507409553361" MODIFIED="1507752345448" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="3">FRBR</font></b><font size="3">&#160;- Functional Requirements for Bibliographic Records </font>
    </p>
    <p>
      <font size="3">&gt; mod&#232;le pour les notices bibliographiques </font>
    </p>
    <p>
      <font size="3">Pr&#233;sentation : </font><span style="font-size: 11.0pt; line-height: 107%; font-family: Calibri,sans-serif"><font size="3" face="Calibri,sans-serif"><a href="http://www.bnf.fr/fr/professionnels/modelisation_ontologies/a.modele_FRBR.html">http://www.bnf.fr/fr/professionnels/modelisation_ontologies/a.modele_FRBR.html</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="1" TRANSPARENCY="200" DASH="7 7" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1821534221" STARTINCLINATION="2121;244;" ENDINCLINATION="2120;244;" STARTARROW="DEFAULT" ENDARROW="DEFAULT"/>
<font SIZE="14" BOLD="false"/>
<node ID="ID_1850417396" CREATED="1507409553361" MODIFIED="1507751627153" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font face="SansSerif" size="3">FRBR(er)</font></b>
    </p>
    <p>
      <font face="SansSerif" size="3">(version &quot;entit&#233; relation&quot;) </font>
    </p>
    <p>
      <font size="11.0pt" face="Calibri,sans-serif"><a href="https://www.ifla.org/publications/functional-requirements-for-bibliographic-records">https://www.ifla.org/publications/functional-requirements-for-bibliographic-records</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="false"/>
</node>
<node ID="ID_1532474395" CREATED="1507409553361" MODIFIED="1507751939070" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="3">FRBRoo</font></b>
    </p>
    <p>
      <font size="3">(version &quot;orient&#233; objet&quot;) </font>
    </p>
    <p class="MsoNormal" style="line-height: normal">
      <span style="font-size: 12.0pt; font-family: SansLligraphy,sans-serif"><font size="3" face="SansSerif">Mod&#232;le conceptuel pour l'information bibliographique, dans un formalisme orient&#233; objet. </font></span>
    </p>
    <p class="MsoNormal" style="line-height: normal">
      <span style="font-size: 12.0pt; font-family: SansLligraphy,sans-serif"><font size="3" face="SansSerif"><a href="https://www.ifla.org/publications/node/11240">https://www.ifla.org/publications/node/11240</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="false"/>
</node>
<node ID="ID_1607508567" CREATED="1507454916289" MODIFIED="1507753012583" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>FRAD</b>&#160;- Functional Requirements for Authority Data
    </p>
    <p>
      <font face="SansSerif" size="3">Fonctionnalit&#233;s requises des donn&#233;es d'autorit&#233;</font>
    </p>
    <p>
      extension aux donn&#233;es d'autorit&#233; (mod&#232;le conceptuel)
    </p>
    <p class="MsoNormal" style="line-height: normal">
      <a href="https://www.ifla.org/publications/functional-requirements-for-authority-data">https://www.ifla.org/publications/functional-requirements-for-authority-data</a>&#160;
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="false"/>
</node>
<node ID="ID_657637613" CREATED="1507454935996" MODIFIED="1507752993494" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font face="SansSerif" size="3">FRSAD</font></b><font face="SansSerif" size="3">&#160;- Functional&#160;&#160;Requirements for Subject&#160;Authority Data </font>
    </p>
    <p>
      <font face="SansSerif" size="3">Fonctionnalit&#233;s requises des donn&#233;es d'autorit&#233;&#160;mati&#232;re </font>
    </p>
    <p>
      <font face="SansSerif" size="3">Extension &#224; la notion de sujet ((mod&#232;le conceptuel) </font>
    </p>
    <p>
      <span style="font-size: 12.0pt; line-height: 107%; font-family: Times New Roman,serif"><font size="3" face="SansSerif">&#160;</font></span><font size="12.0pt" face="SansLligraphy,sans-serif"><span style="font-size: 12.0pt; line-height: 107%; font-family: SansLligraphy,sans-serif"><a href="https://www.ifla.org/node/5849">https://www.ifla.org/node/5849</a></span></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="false"/>
</node>
</node>
</node>
<node ID="ID_1399360983" CREATED="1493286200441" MODIFIED="1507753379195" COLOR="#009933" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3>
      <font size="3">Donn&#233;es g&#233;ographiques<o p="#DEFAULT" size="3"></o></font>
    </h3>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
<node ID="ID_1253599285" CREATED="1507411419940" MODIFIED="1507753369139" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="3" face="SansSerif"><b>INSPIRE</b>&#160; </font>
    </p>
    <p>
      <font size="3" face="SansSerif">(directive europ&#233;enne concernant les donn&#233;es g&#233;ographiques) </font>
    </p>
    <p>
      <span style="font-size: 11.0pt; line-height: 107%; font-family: SansSerif,serif"><font size="11.0pt" face="SansSerif,serif"><a href="http://cnig.gouv.fr/?page_id=8991">http://cnig.gouv.fr/?page_id=8991</a></font></span>&#160;
    </p>
    <p>
      <font size="3" face="SansSerif"><a href="http://inspire.ec.europa.eu/">http://inspire.ec.europa.eu/ </a></font>
    </p>
    <p>
      M&#233;tadonn&#233;es : <span style="font-size: 11.0pt; line-height: 107%; font-family: Calibri,sans-serif"><font size="11.0pt" face="Calibri,sans-serif"><a href="http://cnig.gouv.fr/?page_id=2916">http://cnig.gouv.fr/?page_id=2916</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="13" BOLD="false"/>
</node>
<node ID="ID_409602949" CREATED="1507411343533" MODIFIED="1507803812681" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="SansSerif" size="3"><b>WGS84</b> </font>
    </p>
    <p>
      <span style="font-size: 11.0pt; line-height: 107%; font-family: Calibri,sans-serif"><font size="11.0pt" face="Calibri,sans-serif"><a href="https://fr.wikipedia.org/wiki/WGS_84">https://fr.wikipedia.org/wiki/WGS_84</a></font></span>
    </p>
    <p>
      <a href="https://fr.wikipedia.org/wiki/Syst%C3%A8me_g%C3%A9od%C3%A9sique" title="Syst&#xe8;me g&#xe9;od&#xe9;sique"><font face="SansSerif" size="3">syst&#232;me g&#233;od&#233;sique</font></a><font face="SansSerif" size="3">&#160;mondial, utilis&#233; par les GPS </font>
    </p>
    <p>
      <font face="SansSerif" size="3">&gt; coordonn&#233;es latitude, longitude</font>
    </p>
  </body>
</html>

</richcontent>
<font SIZE="14" BOLD="false"/>
</node>
<node TEXT="WKT - Well-known text (mode texte)&#xa;WKB - Well-known binary (mode binaire pour &#xe9;change entre BdD)&#xa;format pour repr&#xe9;senter des objets g&#xe9;om&#xe9;triques vectoriels issus des SIG" ID="ID_783755689" CREATED="1507411364062" MODIFIED="1507753395960" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="false"/>
</node>
</node>
<node ID="ID_1895526281" CREATED="1493286219293" MODIFIED="1507537293697" COLOR="#009933" STYLE="bubble" HGAP_QUANTITY="39.4999992400408 pt" VSHIFT_QUANTITY="0.7499999776482589 pt"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3>
      <span>Image</span>
    </h3>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
<node ID="ID_1941208377" CREATED="1507409446851" MODIFIED="1507753403948" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      IPTC <b>Photo Metadata Standard </b>
    </p>
    <p>
      <b>Documenter la photo num&#233;rique (support &amp; contenu...)</b>
    </p>
    <p>
      http://iptc.org/standards/photo-metadata/iptc-standard/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="false"/>
</node>
<node TEXT="EXIF&#xa;M&#xe9;tadonn&#xe9;es techniques de l&apos;image num&#xe9;rique" ID="ID_1420772691" CREATED="1507455546429" MODIFIED="1507457369085" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="IIIF - International Image Interoperability Framework&#xa;interop&#xe9;rabilit&#xe9; de l&apos;image: standard &amp; outils&#xa;http://iiif.io/" ID="ID_355455101" CREATED="1507409464974" MODIFIED="1507457439353" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="travaux de 3D-ICONS" ID="ID_706762581" CREATED="1507463066701" MODIFIED="1507751434094" COLOR="#000000" STYLE="bubble">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="1" TRANSPARENCY="200" DASH="2 7 7 7" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1759495061" STARTINCLINATION="1792;94;" ENDINCLINATION="2513;0;" STARTARROW="NONE" ENDARROW="NONE"/>
<font SIZE="14" BOLD="true" ITALIC="true"/>
</node>
</node>
<node ID="ID_1580546607" CREATED="1493286155617" MODIFIED="1507407546865" COLOR="#009933" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4" face="Times New Roman,serif">Musique</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
<node ID="ID_291560361" CREATED="1507416886207" MODIFIED="1507416942532" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4" face="Times New Roman,serif"><b>Music Encoding Initiative </b></font>
    </p>
    <p>
      <font size="4" face="Times New Roman,serif">&#160;<a href="https://music-encoding.org/">https://music-encoding.org/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node ID="ID_991781143" CREATED="1493286174506" MODIFIED="1507407508129" COLOR="#009933" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3>
      <span>Patrimoine culturel<o p="#DEFAULT"></o></span>
    </h3>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
<node ID="ID_403132789" CREATED="1507412349047" MODIFIED="1507412502324" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>EDM</b>&#160;- Europeana Data Model
    </p>
    <p>
      Mod&#232;le des m&#233;tadonn&#233;es d'Europeana
    </p>
    <p>
      https://pro.europeana.eu/page/edm-documentation
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="CIDOC CRM&#xa;Mod&#xe8;le conceptuel de r&#xe9;f&#xe9;rence (ontologie) pour les donn&#xe9;es du patrimoine culturel&#xa;http://www.cidoc-crm.org/" ID="ID_1029898561" CREATED="1507409643037" MODIFIED="1507412299219" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
<node ID="ID_1620468436" CREATED="1507417035980" MODIFIED="1507455738727" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4">Erlangen CRM 170309 :&#160;version OWL fond&#233;e sur le&#160;&#160;CIDOC-CRM 6.2.2) :</font><font size="4" face="Times New Roman,serif">&#160; </font>
    </p>
    <p>
      <font size="4" face="Times New Roman,serif"><a href="http://erlangen-crm.org/current-version">http://erlangen-crm.org/current-version</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
<node ID="ID_1975696257" CREATED="1507412756400" MODIFIED="1507413386186" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      extension...
    </p>
    <p>
      <b>CRMArcheo</b>. CRMDig. CRMGeo. CRMInf...
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
<node ID="ID_614009691" CREATED="1507451321063" MODIFIED="1507451439174" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      mod&#232;le British Museum
    </p>
    <p>
      (D. Oldman, <i>et al</i>.)
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
<node ID="ID_1182768923" CREATED="1507456869551" MODIFIED="1507463936865" COLOR="#4a7fc0" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4">mod&#232;le <b><i>ModRef</i></b>&#160; </font>
    </p>
    <p>
      <font size="4">LabEx &quot;Les pass&#233;s dans le pr&#233;sent&quot; </font>
    </p>
  </body>
</html>
</richcontent>
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#33cc00" WIDTH="2" TRANSPARENCY="200" DASH="3 3" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_411666672" STARTINCLINATION="449;-34;" ENDINCLINATION="357;134;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#33cc00" WIDTH="2" TRANSPARENCY="200" DASH="3 3" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1620468436" STARTINCLINATION="355;-82;" ENDINCLINATION="193;-179;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#33cc00" WIDTH="2" TRANSPARENCY="200" DASH="3 3" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1984344107" STARTINCLINATION="561;43;" ENDINCLINATION="452;-13;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font SIZE="14" BOLD="true"/>
</node>
<node ID="ID_173658939" CREATED="1507463852777" MODIFIED="1507464050203" COLOR="#4a7fc0" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Mod&#232;le pour <b>ArSol</b>
    </p>
    <p>
      Fouilles arch&#233;ologiques
    </p>
    <p>
      (Tours, LAT-Cit&#232;res)
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node TEXT="LIDO&#xa;Mod&#xe8;le pour l&apos;int&#xe9;rop&#xe9;rabilit&#xe9; des&#xa;collections mus&#xe9;ales&#xa;http://network.icom.museum/cidoc/working-groups/lido/what-is-lido/" ID="ID_1802411638" CREATED="1507409662758" MODIFIED="1507533724616" COLOR="#000000" STYLE="bubble">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="1" TRANSPARENCY="200" DASH="3 3" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1272367060" STARTINCLINATION="1845;352;" ENDINCLINATION="323;308;" STARTARROW="DEFAULT" ENDARROW="DEFAULT"/>
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node ID="ID_171579018" CREATED="1493286136311" MODIFIED="1507407508113" COLOR="#009933" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3>
      <span>Textuel (&#233;dition, &#233;pigraphie...)</span>
    </h3>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
<node ID="ID_1405636630" CREATED="1507409570744" MODIFIED="1507416172196" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      TEI - Text Encoding Initiative
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://www.tei-c.org/index.xml">http://www.tei-c.org/index.xml</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
<node TEXT="TEI5" ID="ID_1454042196" CREATED="1507409588917" MODIFIED="1507410389495" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node TEXT="EpiDoc&#xa;(sch&#xe9;ma et outils pour l&apos;&#xe9;pigraphie)&#xa;https://sourceforge.net/p/epidoc/wiki/Home/" ID="ID_1096938333" CREATED="1507409606073" MODIFIED="1507453899739" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node ID="ID_1901185906" CREATED="1493286190792" MODIFIED="1507407508144" COLOR="#009933" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3>
      <span lang="EN-US">Vocabulaires, th&#233;saurus, taxonomie...<o p="#DEFAULT"></o></span>
    </h3>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
<node ID="ID_301909157" CREATED="1507410434436" MODIFIED="1507455845549" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4"><b>SKOS</b>&#160;: Simple Knowledge Organization System </font>
    </p>
    <p>
      <font size="4">th&#233;saurus, taxonomie, vocabulaires... </font>
    </p>
    <p>
      <font size="4">https://www.w3.org/2004/02/skos/ </font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
<node ID="ID_213093458" CREATED="1507410408148" MODIFIED="1507463902925" COLOR="#5294d5" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4" face="Times New Roman,serif">ISO25964-Thesaurus : the international standard for thesauri and interoperability with other vocabularies </font>
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif">http://www.niso.org/schemas/iso25964/</font></span>&#160;<font size="4" face="Times New Roman,serif">&#160;</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node TEXT="DIVERS" ID="ID_1097772092" CREATED="1507413124950" MODIFIED="1507462176370" COLOR="#009933" STYLE="bubble" VGAP_QUANTITY="0.0 pt">
<font SIZE="14" BOLD="true"/>
<node TEXT="ontologie" ID="ID_1617561606" CREATED="1507409814099" MODIFIED="1507409826296" COLOR="#009933" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
<node ID="ID_508401977" CREATED="1507411576972" MODIFIED="1507411688172" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      OWL<b>&#160;</b>- Web Ontology Language
    </p>
    <p>
      https://www.w3.org/2001/sw/wiki/OWL
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node TEXT="Web" ID="ID_828653389" CREATED="1507412983308" MODIFIED="1507462203085" COLOR="#009933" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
<node ID="ID_854323222" CREATED="1507412994636" MODIFIED="1507413065537" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="3">schema.org</font></b>
    </p>
    <p>
      <font size="3">sch&#233;ma de micro-donn&#233;es utilis&#233; sur le Web</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node TEXT="informatique" ID="ID_771972628" CREATED="1507413150161" MODIFIED="1507413300965" COLOR="#009933" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
<node TEXT="http" ID="ID_318653501" CREATED="1507413193065" MODIFIED="1507413262617" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="html" ID="ID_1903536837" CREATED="1507413236614" MODIFIED="1507413262634" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
<node ID="ID_1033398454" CREATED="1507413208435" MODIFIED="1507458069211" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>XML</b>&#160;-Extensible Markup Language
    </p>
    <p>
      Metalangage de balisage
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
<node ID="ID_516778793" CREATED="1507413173378" MODIFIED="1507417696314" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      RDF - <span lang="EN-US" style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif">Resource Description Framework </font></span>
    </p>
    <p>
      <span lang="EN-US"><font size="12.0pt" face="Times New Roman,serif"><a href="https://www.w3.org/RDF/">https://www.w3.org/RDF/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
</node>
</node>
<node ID="ID_55426671" CREATED="1507753480915" MODIFIED="1507753480915" LINK="http://cnig.gouv.fr/?page_id=2916"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <span style="font-size: 11.0pt; line-height: 107%; font-family: Calibri,sans-serif"><font size="11.0pt" face="Calibri,sans-serif"><a href="http://cnig.gouv.fr/?page_id=2916">http://cnig.gouv.fr/?page_id=2916</a></font></span>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" FOLDED="true" POSITION="left" ID="ID_832416630" CREATED="1507407923407" MODIFIED="1507418775569" COLOR="#a47f10" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="5">Vocabulaires </font>
    </p>
    <p>
      <font size="5">th&#233;saurus </font>
    </p>
    <p>
      <font size="5">r&#233;f&#233;rentiels</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="22"/>
<edge COLOR="#e8a60c"/>
<node ID="ID_718114043" CREATED="1507410809228" MODIFIED="1507417960591" COLOR="#cc9900"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="4">Identifiant, r&#233;f&#233;rentiels</font></b>
    </p>
    <p>
      <font color="#003399">http://www.bnf.fr/fr/professionnels/modelisation_ontologies/a.modele_FRBR.html</font>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="&quot;PIDs&quot; -Permanent identifier (URI)&#xa;identifiants stables" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1496336932" CREATED="1507410854338" MODIFIED="1507455939628" COLOR="#a47f10" STYLE="bubble">
<font SIZE="12"/>
<edge COLOR="#e8a60c"/>
<node TEXT="ARK" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_75768510" CREATED="1507410863973" MODIFIED="1507462274240" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#e8a60c"/>
</node>
<node TEXT="DOI / HANDLE" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_963060020" CREATED="1507410896156" MODIFIED="1507462279910" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#e8a60c"/>
</node>
</node>
<node TEXT="r&#xe9;f&#xe9;rentiels Personnes" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1714915435" CREATED="1507411162653" MODIFIED="1507455973610" COLOR="#a47f10" STYLE="bubble">
<font SIZE="12"/>
<edge COLOR="#e8a60c"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1518596908" CREATED="1507411032334" MODIFIED="1507418476213" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="3">ISNI</font><font size="4">&#160; </font></b>
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif">International Standard Name Identifier (ISO 27729) </font></span>
    </p>
    <p>
      <font size="3">http://www.isni.org/</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
<edge COLOR="#e8a60c"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1873882379" CREATED="1507411179951" MODIFIED="1507455990372" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>ORCID</b>
    </p>
    <p>
      monde de la recherche
    </p>
    <p>
      http://www.isni.org/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
<edge COLOR="#e8a60c"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1890086814" CREATED="1507417966565" MODIFIED="1507457757315" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="Times New Roman,serif"><b>VIAF</b>-Virtual International Authority File</font>
    </p>
    <p>
      <font face="Times New Roman,serif">Fichier de r&#233;f&#233;rence pour personnes ou collectivit&#233;s contenues dans d'autres fichiers d'autorit&#233;</font>
    </p>
    <p>
      <font face="Times New Roman,serif"><a href="https://viaf.org/">https://viaf.org/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
<edge COLOR="#e8a60c"/>
</node>
</node>
<node TEXT="r&#xe9;f&#xe9;rentiels pour publications" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_489003718" CREATED="1507411197105" MODIFIED="1507456029233" COLOR="#a47f10" STYLE="bubble">
<font SIZE="12"/>
<edge COLOR="#e8a60c"/>
<node TEXT="ISBN" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_459334582" CREATED="1507410840287" MODIFIED="1507411214096" COLOR="#000000" STYLE="bubble">
<font SIZE="12"/>
</node>
<node TEXT="ISSN" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_985372630" CREATED="1507410822770" MODIFIED="1507411217642" COLOR="#000000" STYLE="bubble">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Th&#xe9;saurus&#xa;vocabulaires" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_541958875" CREATED="1507409853396" MODIFIED="1507416829744" COLOR="#a47f10" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
<edge COLOR="#e8a60c"/>
<node TEXT="vocabulaires du Minist&#xe8;re de la culture" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_739182589" CREATED="1507414158562" MODIFIED="1507482862631" COLOR="#0066cc" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" FOLDED="true" ID="ID_1890660536" CREATED="1507414995763" MODIFIED="1507415108445" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Th&#233;saurus de la d&#233;signation</b>
    </p>
    <p>
      http://www.culture.gouv.fr/culture/inventai/patrimoine/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1327108007" CREATED="1507414814503" MODIFIED="1507415111746" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Th&#233;saurus de la d&#233;signation des objets mobiliers</b>
    </p>
    <p>
      http://data.culture.fr/thesaurus/page/ark:/67717/T69
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_696997314" CREATED="1507414733247" MODIFIED="1507415114001" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Th&#233;saurus de la d&#233;signation des &#339;uvres architecturales et des espaces am&#233;nag&#233;s</b>
    </p>
    <p>
      http://data.culture.fr/thesaurus/page/ark:/67717/T96
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1586248183" CREATED="1507414177311" MODIFIED="1507456246870" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      langage d'indexation <b>RAMEAU</b>&#160;(BnF)
    </p>
    <p>
      http://rameau.bnf.fr/informations/rameauenbref.htm
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_399187800" CREATED="1507413419913" MODIFIED="1507457899547" COLOR="#0066cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>PACTOLS</b>
    </p>
    <p>
      &gt; biblioth&#232;ques, arch&#233;ologie
    </p>
    <p>
      (Frantiq)
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_154945293" CREATED="1507414089574" MODIFIED="1507417464824" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>ICONCLASS</b>
    </p>
    <p>
      (iconographie)
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://www.iconclass.nl/home">http://www.iconclass.nl/home</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
<node ID="ID_771959528" CREATED="1507413440080" MODIFIED="1507457909649"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Vocabulaires Getty</b>
    </p>
    <p>
      http://www.getty.edu/research/tools/vocabularies/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1446901518" CREATED="1507413795230" MODIFIED="1507414055822" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>AAT</b>&#160;- Art and Architecture Thesaurus
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1953390936" CREATED="1507413736185" MODIFIED="1507414055854" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>CONA</b>&#160;- Cultural Objects Names Authorities
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1766331174" CREATED="1507413731116" MODIFIED="1507414055869" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>ULAN</b>&#160;- Union List of Artists Name
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1858992493" CREATED="1507413809878" MODIFIED="1507414055885" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>TGN</b>&#160;- Thesaurus of Geographic Names
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
</node>
<node TEXT="G&#xe9;ographie" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_947139027" CREATED="1507415385444" MODIFIED="1507493759706" COLOR="#a47f10" STYLE="bubble">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#999900" WIDTH="2" TRANSPARENCY="200" DASH="3 3" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1858992493" STARTINCLINATION="490;0;" ENDINCLINATION="-13;99;" STARTARROW="NONE" ENDARROW="NONE"/>
<font SIZE="14" BOLD="true"/>
<edge COLOR="#e8a60c"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_211351024" CREATED="1507415396471" MODIFIED="1507456270689" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>geonames</b>
    </p>
    <p>
      gazetteer
    </p>
    <p>
      <font size="12.0pt" face="Times New Roman,serif"><a href="http://www.geonames.org/">http://www.geonames.org/</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_587466829" CREATED="1507415420687" MODIFIED="1507463009930" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>pleiades</b>&#160;(&amp; pelagios)
    </p>
    <p>
      g&#233;ographie antique dans le LOD
    </p>
    <p>
      https://pleiades.stoa.org/help/lod
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1876468581" CREATED="1507415269683" MODIFIED="1507415343102" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Thesaurus de l'UNESCO</b>
    </p>
    <p>
      http://vocabularies.unesco.org/browser/thesaurus/fr/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="ressources" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" FOLDED="true" POSITION="left" ID="ID_1137571423" CREATED="1507407707117" MODIFIED="1507408379549" COLOR="#872ce2" STYLE="bubble">
<font SIZE="18" BOLD="true"/>
<edge COLOR="#872ce2"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1091270823" CREATED="1507409227437" MODIFIED="1507453065421" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>LOV- Linked Open Vocabularies </b>
    </p>
    <p>
      <b>panorama des vocabulaires</b>
    </p>
    <p>
      http://lov.okfn.org/dataset/lov/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_727644814" CREATED="1507543418179" MODIFIED="1507543861551" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <span lang="EN-US" style="font-size: 12.0pt; font-family: Calibri,sans-serif"><font size="12.0pt" face="Calibri,sans-serif"><b>Linked Open Data (W3C) :</b>&#160;</font></span><font size="12.0pt" face="Calibri,sans-serif"><span lang="EN-US"><a href="https://www.w3.org/wiki/SweoIG/TaskForces/CommunityProjects/LinkingOpenData">https://www.w3.org/wiki/SweoIG/TaskForces/CommunityProjects/LinkingOpenData</a></span><span lang="EN-US" style="font-size: 12.0pt; font-family: Calibri,sans-serif"><br/><br/></span></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_392906649" CREATED="1507543863990" MODIFIED="1507544003733" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><span lang="EN-US" style="font-family: Calibri,sans-serif"><font face="Calibri,sans-serif" size="3">LOD-Cloud</font></span></b><font face="Calibri,sans-serif" size="3"><span lang="EN-US" style="font-family: Calibri,sans-serif">&#160;:&#160; </span><span style="font-family: Calibri,sans-serif"><em>Linking Open Data cloud</em></span><span lang="EN-US" style="font-family: Calibri,sans-serif">&#160;diagram : </span></font>
    </p>
    <p>
      <span lang="EN-US" style="font-family: Calibri,sans-serif"><font face="Calibri,sans-serif" size="3">&#160;</font></span><font face="Calibri,sans-serif" size="3"><span lang="EN-US"><a href="http://lod-cloud.net/">http://lod-cloud.net/</a></span><span lang="EN-US" style="font-family: Calibri,sans-serif">&#160;<o p="#DEFAULT" size="3"></o></span></font>
    </p>
    <span lang="EN-US" style="font-size: 12.0pt; font-family: Calibri,sans-serif"><font size="3" face="Calibri,sans-serif">et&#160; <b>LOD-cloud 2014</b>&#160;: </font></span><font size="3" face="Calibri,sans-serif"><span lang="EN-US"><a href="http://lod-cloud.net/versions/2014-08-30/lod-cloud_colored.svg">http://lod-cloud.net/versions/2014-08-30/lod-cloud</a></span></font><span lang="EN-US"><a href="http://lod-cloud.net/versions/2014-08-30/lod-cloud_colored.svg"><font size="12.0pt" face="Calibri,sans-serif">_colored.svg</font></a></span>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1597627129" CREATED="1507408971469" MODIFIED="1507453334933" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="3">Plume </font></b>
    </p>
    <p>
      <b><font size="3">r&#233;pertoire de logiciels</font></b>
    </p>
    <p>
      <font size="3">https://projet-plume.org/</font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="gisements de (m&#xe9;ta)donn&#xe9;es" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1529521558" CREATED="1507412883409" MODIFIED="1507412925141" COLOR="#872ce2" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<node TEXT="dbpedia" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_740461552" CREATED="1507409351901" MODIFIED="1507413679495" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1635004539" CREATED="1507409377211" MODIFIED="1507456614997" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      wikidata
    </p>
    <p>
      base de donn&#233;es libre, collaborative, multilingue collectant des donn&#233;es structur&#233;es pour wikipedia, wikimedia Commons, et autres
    </p>
    <p>
      <font size="12.0pt" face="Times New Roman,serif"><a href="https://www.wikidata.org/wiki/Wikidata:Main_Page">https://www.wikidata.org/wiki/Wikidata:Main_Page</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="data.bnf.fr" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_713699723" CREATED="1507409388745" MODIFIED="1507753626981" COLOR="#0033cc" STYLE="bubble">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#cc0000" WIDTH="1" TRANSPARENCY="200" DASH="7 7" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1668061925" STARTINCLINATION="1664;250;" ENDINCLINATION="1792;-154;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1428002487" CREATED="1507418638093" MODIFIED="1507418687635" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="4">data.gouv</font></b>
    </p>
    <p>
      <span lang="EN-US"><font size="4" face="Times New Roman,serif"><a href="http://www.data.gouv.fr/fr/">http://www.data.gouv.fr/fr/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
</node>
<node TEXT="juridique" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_895383317" CREATED="1507418709209" MODIFIED="1507418728565" COLOR="#872ce2" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<node TEXT="Licences Creatives Commons" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_765553631" CREATED="1507453349984" MODIFIED="1507453515106" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
<node TEXT="CC BY-***" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1193437175" CREATED="1507453603651" MODIFIED="1507533843248" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="Public Domain Mark" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_521730638" CREATED="1507453644703" MODIFIED="1507453689559" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="CC0" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1195750809" CREATED="1507453620033" MODIFIED="1507453689559" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
</node>
<node TEXT="Licence Ouverte&#xa;Open Licence" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1931560551" CREATED="1507453393468" MODIFIED="1507496667321" COLOR="#0033cc" STYLE="bubble">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="1" TRANSPARENCY="200" DASH="3 3" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_490536412" STARTINCLINATION="1699;-400;" ENDINCLINATION="-649;-246;" STARTARROW="DEFAULT" ENDARROW="DEFAULT"/>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="GNU" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_171552119" CREATED="1507453438067" MODIFIED="1507453519337" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="CeCILL - Ce(A)C(nrs)(INRIA)L(ogiicels)L(ibre)&#xa;compatible GNU GPL" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1080850435" CREATED="1507453491518" MODIFIED="1507479022860" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#ff00ff"/>
</node>
<node TEXT="open data / open access" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1000702962" CREATED="1507533755429" MODIFIED="1507533817616" COLOR="#872ce2" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
</node>
</node>
<node TEXT="exemples" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_610287972" CREATED="1507413480898" MODIFIED="1507418648894" COLOR="#872ce2" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<node TEXT="JocondeLab" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_302333716" CREATED="1507413492337" MODIFIED="1507413692513" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="EuropeanaLab" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1859985706" CREATED="1507413538872" MODIFIED="1507413679547" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1272367060" CREATED="1507416975657" MODIFIED="1507418648894" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>MIMO</b>
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif">http://www.mimo-db.eu/</font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1211848761" CREATED="1507415575629" MODIFIED="1507462164375" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>pleiades </b>
    </p>
    <p>
      <b>g&#233;ographie antique dans le LOD</b>
    </p>
    <p>
      https://pleiades.stoa.org/help/lod
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_688903389" CREATED="1507418381931" MODIFIED="1507418414402" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><b>BeQuali</b>&#160;- catalogue d&#8217;enqu&#234;tes de sciences humaines et sociales </font></span>
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://bequali.fr/fr/">http://bequali.fr/fr/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node ID="ID_125882804" CREATED="1507544013589" MODIFIED="1507544067708"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="3">plateforme </font><b><span lang="EN-US" style="font-family: Calibri,sans-serif"><font face="Calibri,sans-serif" size="3">CoCoON</font></span></b><font face="Calibri,sans-serif" size="3"><span lang="EN-US" style="font-family: Calibri,sans-serif">&#160;- COllections de COrpus Oraux Num&#233;riques<o p="#DEFAULT" size="3"></o> </span></font>
    </p>
    <p>
      <span lang="EN-US"><font size="3" face="Calibri,sans-serif"><a href="http://cocoon.huma-num.fr/exist/crdo">http://cocoon.huma-num.fr/exist/crdo</a></font></span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_291532936" CREATED="1507479082657" MODIFIED="1507544849543" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal">
      <b><span style="font-size: 12.0pt"><font size="12.0pt">SyMoGIH <o p="#DEFAULT"></o></font></span></b>
    </p>
    <p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal">
      <span style="font-size: 12.0pt"><font size="12.0pt">gestion num&#233;rique de l&#8217;information historique<o p="#DEFAULT"></o></font></span>
    </p>
    <p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal">
      <span style="font-size: 12.0pt"><font size="12.0pt"><a href="http://symogih.org/">http://symogih.org/</a><o p="#DEFAULT"></o></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1352092009" CREATED="1507479110142" MODIFIED="1507544942453" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal">
      <span class="titre1ni"><b>DMF</b>-Dictionnaire du Moyen Fran&#231;ais<o p="#DEFAULT"></o></span>
    </p>
    <p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal">
      <span style="font-size: 12.0pt"><font size="12.0pt"><a href="http://www.atilf.fr/dmf/">http://www.atilf.fr/dmf/</a><o p="#DEFAULT"></o></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="projet Nomisma.org&#xa;La numismatique dans le LOD&#xa;Ontologie + th&#xe9;saurus, etc." LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1810322600" CREATED="1507413506911" MODIFIED="1507462589258" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="projet Biblissima" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1821534221" CREATED="1507413516125" MODIFIED="1507533870622" COLOR="#0033cc" STYLE="bubble">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="1" TRANSPARENCY="200" DASH="7 7" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_355455101" STARTINCLINATION="2758;0;" ENDINCLINATION="2758;0;" STARTARROW="DEFAULT" ENDARROW="DEFAULT"/>
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="1" TRANSPARENCY="200" DASH="7 7" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1029898561" STARTINCLINATION="1939;-320;" ENDINCLINATION="1279;277;" STARTARROW="DEFAULT" ENDARROW="DEFAULT"/>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1925116345" CREATED="1507418118112" MODIFIED="1507418428109" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4"><b>HAL</b> </font>
    </p>
    <p>
      <span lang="EN-US"><font size="4" face="Times New Roman,serif"><a href="https://hal.archives-ouvertes.fr/">https://hal.archives-ouvertes.fr/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_969754922" CREATED="1507418123696" MODIFIED="1507418628638" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font size="4">HAL-SHS</font></b>
    </p>
    <p>
      <span lang="EN-US"><font size="4" face="Times New Roman,serif"><a href="https://halshs.archives-ouvertes.fr/">https://halshs.archives-ouvertes.fr/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_164899779" CREATED="1507418128011" MODIFIED="1507418626423" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4"><b>MediHAL</b> </font>
    </p>
    <p>
      <span lang="EN-US"><font size="4" face="Times New Roman,serif"><a href="https://medihal.archives-ouvertes.fr/">https://medihal.archives-ouvertes.fr/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
</node>
</node>
<node TEXT="Bibliographie / webographie" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_94692783" CREATED="1507413459936" MODIFIED="1507533912125" COLOR="#872ce2" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_311501855" CREATED="1507451195019" MODIFIED="1507534684304" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Tim Berners-Lee
    </p>
    <p>
      &gt; WWW
    </p>
    <p>
      &gt; <i><a href="https://fr.wikipedia.org/wiki/World_Wide_Web_Consortium" title="">World Wide Web Consortium</a></i>&#160;(W3C) (1997...)
    </p>
    <p>
      &gt; Semantic Web, Linked Open Data
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="https://fr.wikipedia.org/wiki/Tim_Berners-Lee">https://fr.wikipedia.org/wiki/Tim_Berners-Lee</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_758962353" CREATED="1507534805532" MODIFIED="1507535180302" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <i>Semantic Web Road Map&#160;</i><b>(1998)</b>
    </p>
    <p>
      <font size="12.0pt" face="Times New Roman,serif"><a href="https://www.w3.org/DesignIssues/Semantic.html">https://www.w3.org/DesignIssues/Semantic.html</a></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" FOLDED="true" ID="ID_1510371374" CREATED="1507535054591" MODIFIED="1507535204073" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="3"><i>Linked</i>&#160;<i>Data</i>&#160;(2006) </font>
    </p>
    <p>
      <a href="https://www.w3.org/DesignIssues/LinkedData.html"><font size="3">https://www.w3.org/DesignIssues/LinkedData.html</font></a><font size="3"><o p="#DEFAULT" size="3"></o></font>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<node TEXT="5 STARS" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" FOLDED="true" ID="ID_833453763" CREATED="1507451241625" MODIFIED="1507451282818" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<node ID="ID_49935967" CREATED="1507535451759" MODIFIED="1507535512467"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <img src="../../../__AVS/597992118v2_350x350_Back.jpg"/>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_840265745" CREATED="1507533942006" MODIFIED="1507534020260" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Minist&#232;re de la culture : innovations techniques, feuilles de route...
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://www.culturecommunication.gouv.fr/Thematiques/Innovation-numerique">http://www.culturecommunication.gouv.fr/Thematiques/Innovation-numerique</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_903383385" CREATED="1507416425378" MODIFIED="1507534199704" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Observatoire des technologies de l'IST<o p="#DEFAULT">&#160;</o>
    </p>
    <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif"><a href="http://ist.blogs.inra.fr/technologies/">http://ist.blogs.inra.fr/technologies/</a></font></span>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1550084856" CREATED="1507453379361" MODIFIED="1507534316606" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      blog S.I.Lex - carnet de veille d'un juriste et d'un biblioth&#233;caire
    </p>
    <p>
      <a href="http://ist.blogs.inra.fr/technologies/">http://ist.blogs.inra.fr/technologies/</a><o p="#DEFAULT"></o>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
<node TEXT="wiikipedia" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_80296948" CREATED="1507409085016" MODIFIED="1507534213067" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1522675585" CREATED="1507451496851" MODIFIED="1507543284407" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      D. Oldman, et al., <i><span style="font-size: 12.0pt"><font size="12.0pt">The CIDOC Conceptual Reference Model (CIDOC-CRM): PRIMER<o p="#DEFAULT"></o></font></span></i>
    </p>
    <p class="MsoNormal">
      <span style="font-size: 12.0pt; line-height: 107%"><font size="12.0pt"><a href="http://old.cidoc-crm.org/docs/CRMPrimer_v1.1.pdf">http://old.cidoc-crm.org/docs/CRMPrimer_v1.1.pdf</a><o p="#DEFAULT" style="line-height: 107%"></o></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1180624370" CREATED="1507451147941" MODIFIED="1507463355823" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      E. Berm&#232;s, et al., <i>Le Web s&#233;mantique en biblioth&#232;que</i>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
</node>
<node TEXT="formations" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1416978524" CREATED="1507413632375" MODIFIED="1507415891137" COLOR="#872ce2" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
<node TEXT="plateforme de MOOC" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_744383876" CREATED="1507416244054" MODIFIED="1507416307305" COLOR="#872ce2" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
<node TEXT="http://www.uoh.fr/front/accueil" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_728107247" CREATED="1507416309606" MODIFIED="1507416527407" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="FUN&#xa;https://www.fun-mooc.fr/" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_306422675" CREATED="1507416259544" MODIFIED="1507416529366" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
<node TEXT="MOOC sur le Web s&#xe9;mantqiue" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_855457857" CREATED="1507463369473" MODIFIED="1507463401947" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" FOLDED="true" ID="ID_1197353676" CREATED="1507463417552" MODIFIED="1507545054675" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      MOOC Universit&#233; Paris Nanterre
    </p>
    <p class="MsoNormal" style="line-height: normal">
      <span style="font-size: 12.0pt"><font size="12.0pt">&quot;Bien archiver : la r&#233;ponse au d&#233;sordre num&#233;rique<o p="#DEFAULT"></o>&quot;</font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<node TEXT="MOOC sur les archives" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1246312716" CREATED="1507463432358" MODIFIED="1507463493604" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
</node>
</node>
<node TEXT="Formations en ligne de l&apos;INIST&#xa;(gratuit&#xe9; pour CNRS...)" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1480349463" CREATED="1507453781148" MODIFIED="1507453844699" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
</node>
<node TEXT="" ID="ID_917544994" CREATED="1507453764531" MODIFIED="1507453764531"/>
<node TEXT="Master de l&apos;Ecole des Chartes" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1423214243" CREATED="1507416488971" MODIFIED="1507416519659" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_304845350" CREATED="1507416503505" MODIFIED="1507416594963" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <span style="font-size: 12.0pt; font-family: Times New Roman,serif"><font size="12.0pt" face="Times New Roman,serif">Master CESR</font></span>&#160;(Tours) : TEI...
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="ANF Concevoir et exploiter les sources num&#xe9;riques de la recherche en SHS" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_575963366" CREATED="1507463511674" MODIFIED="1507463681944" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
</node>
<node TEXT="&#xe9;v&#xe9;nements" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1692997768" CREATED="1507415864441" MODIFIED="1507415893304" COLOR="#872ce2" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
<node TEXT="DH" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1832052815" CREATED="1507415874258" MODIFIED="1507415901641" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node TEXT="ThatCamp" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_184491903" CREATED="1507450984881" MODIFIED="1507451042528" COLOR="#000000" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_229343152" CREATED="1507463689007" MODIFIED="1507463828268" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>CAA&#160;- Computer Application in Archaeology</b>
    </p>
    <p>
      informatique et arch&#233;ologie
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#872ce2"/>
</node>
</node>
</node>
<node TEXT="Outils, logiciels&#xa;cms, api..." LOCALIZED_STYLE_REF="AutomaticLayout.level,2" POSITION="right" ID="ID_491891303" CREATED="1507408333542" MODIFIED="1507409752256" COLOR="#d334d3" STYLE="bubble">
<font SIZE="18" BOLD="true"/>
<edge COLOR="#ff66ff"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1765227892" CREATED="1507409758815" MODIFIED="1507544553511" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      (Arches (Getty)
    </p>
    <p>
      mod&#232;le (CIDOC-CRM) et API
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Calibri,sans-serif"><font size="12.0pt" face="Calibri,sans-serif">&#160;<a href="http://archesproject.org/">http://archesproject.org/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="cms g&#xe9;n&#xe9;ralistes" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1914894298" CREATED="1507797287554" MODIFIED="1507797298914" COLOR="#d334d3" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
<node TEXT="Drupal" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1204204629" CREATED="1507408847557" MODIFIED="1507478331290" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1473274221" CREATED="1507408476021" MODIFIED="1507797416622" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="3" face="SansSerif"><b>Omeka</b> </font>
    </p>
    <p>
      <font size="3" face="SansSerif">collections d'images, corpus d'objets / de collection </font>
    </p>
    <p>
      <span style="font-size: 11.0pt; line-height: 107%; font-family: Calibri,sans-serif"><font size="11.0pt" face="Calibri,sans-serif"><a href="https://omeka.org/">https://omeka.org/</a></font></span>
    </p>
  </body>
</html>

</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="SPIP&#xa;article, site web" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1390223917" CREATED="1507408530224" MODIFIED="1507797471443" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
</node>
<node TEXT="Blog, carnet de recherche&#xa;site web" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_929226719" CREATED="1507408566461" MODIFIED="1507478442106" COLOR="#d334d3" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
<node TEXT="wordpress&#xa;blog, site web" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_54503172" CREATED="1507408512204" MODIFIED="1507478739723" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
</node>
</node>
<node TEXT="Zotero&#xa;gestion de bibliographie" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_133650119" CREATED="1507408781700" MODIFIED="1507478833813" COLOR="#d334d3" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="Gestion de th&#xe9;saurus (SKOS/ISO thesaurus)" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1776765549" CREATED="1507408572214" MODIFIED="1507462751144" COLOR="#d334d3" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_695066575" CREATED="1507408743328" MODIFIED="1507479050816" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Ginco</b>
    </p>
    <p>
      (Min. Culture)
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#ff00ff"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_455862093" CREATED="1507408593481" MODIFIED="1507479058631" COLOR="#0033cc" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Opentheso</b>
    </p>
    <p>
      (CNRS)
    </p>
  </body>
</html>
</richcontent>
<font SIZE="12" BOLD="true"/>
<edge COLOR="#ff00ff"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1235466114" CREATED="1507408603314" MODIFIED="1507478347774" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>VocBench</b>
    </p>
    <p>
      http://vocbench.uniroma2.it/
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1899524846" CREATED="1507408869046" MODIFIED="1507478383181" COLOR="#d334d3" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      cartes heuristiques,
    </p>
    <p>
      mod&#233;lisation, dataviz<br/>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
<node TEXT="freemind / freeplane&#xa;carte heuristique" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_441183781" CREATED="1507408890038" MODIFIED="1507478630817" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1659900804" CREATED="1507409688917" MODIFIED="1507544337387" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      protege
    </p>
    <p>
      contruction d'ontologie, de vocabulaire
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Calibri,sans-serif"><font size="12.0pt" face="Calibri,sans-serif"><a href="http://protege.stanford.edu/">http://protege.stanford.edu/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1879533095" CREATED="1507409714185" MODIFIED="1507544395737" COLOR="#000000" STYLE="bubble"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Geph<font size="4">i</font><span style="font-size: 12.0pt; font-family: Calibri,sans-serif"><font size="12.0pt" face="Calibri,sans-serif">- The Open Graph Viz Platform</font></span>
    </p>
    <p>
      mod&#233;lisation et dataviz
    </p>
    <p>
      <span style="font-size: 12.0pt; font-family: Calibri,sans-serif"><font size="12.0pt" face="Calibri,sans-serif">&#160;<a href="https://gephi.org/">https://gephi.org/</a></font></span>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="YED&#xa;mod&#xe9;lisation (UML...)" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1014996254" CREATED="1507415929887" MODIFIED="1507478725659" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node TEXT="m&#xe9;tadonn&#xe9;es de l&apos;image" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1841255505" CREATED="1507496440014" MODIFIED="1507496594332" COLOR="#d334d3" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
<node TEXT="ExifTools &amp; ExifTool-GUI" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_312876339" CREATED="1507496446350" MODIFIED="1507496519770" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="Xnview" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_500263670" CREATED="1507496525857" MODIFIED="1507496546471" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
</node>
<node TEXT="annotation" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1350542724" CREATED="1507544949546" MODIFIED="1507544960958" COLOR="#d334d3" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="OpenRefine&#xa;r&#xe9;organisation, correction de donn&#xe9;es" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_335953248" CREATED="1507409705655" MODIFIED="1507478772904" COLOR="#000000" STYLE="bubble">
<font SIZE="14" BOLD="true"/>
</node>
<node TEXT="DMP OPIDoR&#xa;plan de gestion de donn&#xe9;es / Data Management Plan&#xa;(CNRS-INIST)" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" ID="ID_1907585306" CREATED="1507478846262" MODIFIED="1507479063866" COLOR="#0033cc" STYLE="bubble">
<font SIZE="12" BOLD="true"/>
<edge COLOR="#ff00ff"/>
</node>
</node>
</node>
</map>
